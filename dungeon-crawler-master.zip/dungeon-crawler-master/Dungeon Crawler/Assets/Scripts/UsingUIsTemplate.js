﻿#pragma strict

//calling the UI engine; allowing use of UI in our code
import UnityEngine.UI;

public var healthtxt: Text;

function Start () {
	healthtxt.text = "okay";
}

function Update () {

}