﻿#pragma strict
	var speed: float;
	private var moveX: float;
	private var moveY: float;
	private var rb: Rigidbody2D;
private var direction = "right";
public var coincount: int;

var x: int;
var y: int;
var moveDistance: int;
var moving = false;
var collision = false;
var position: Vector2;
var colliding = false;
var coinText : GUIText;
private var sword: GameObject;
private var swordrotation: RectTransform;
function Start () {
	rb = GetComponent.<Rigidbody2D>();

}
function Update () {

	moveX = Input.GetAxis("Horizontal");
	moveY = Input.GetAxis("Vertical");
	if( moveX < 0){
		direction = "left";
	} else if(moveX > 0){
		direction = "right";
	}
	if( moveY < 0){
		direction = "down";
	} else if(moveY > 0){
		direction = "left";
	}

}

function OnTriggerEnter2D(other: Collider2D){
	if(other.tag == "coin"){
		coincount++;
		Destroy(other.gameObject);
		}
	}

	function UpdateScore(){
		coinText.text = "Coins: " + coincount;
	}

function FixedUpdate () {
	Move();
}

function Move() {
	var movementX = moveX * speed * Time.deltaTime;
	var movementY = moveY * speed * Time.deltaTime;
	var movement = new Vector2( movementX, movementY);
		rb.MovePosition( rb.position + movement);
}
