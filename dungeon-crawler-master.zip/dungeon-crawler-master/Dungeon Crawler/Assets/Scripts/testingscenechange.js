﻿#pragma strict
import UnityEngine.SceneManagement;


function Start () {
}

function Update () {
		if(Input.GetKeyDown("space")){
		print("hello");
			SceneManager.LoadScene(0);
	}	

}
