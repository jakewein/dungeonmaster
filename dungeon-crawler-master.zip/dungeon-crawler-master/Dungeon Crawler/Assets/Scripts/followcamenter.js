﻿#pragma strict

var cam: Camera;
var offsetZ: Vector3;
var camSpeed = 5;

var startMarker: Transform;
var endMarker: Transform;
var selectedRoom = false;
private var startTime: float;
private var journeyLength: float = 1.0;

function Start () {
	cam = Camera.main;
	offsetZ = Vector3(0,0,-10);
}

function Update () {
	if(selectedRoom == true){
		//Distance moved = time * speed.
		var distCovered = (Time.time - startTime) * camSpeed;

		//print("disCovered: " + distCovered + "\n journeyLength: " + journeyLength);

		//Fraction of journey completed = current distance divided by total distance.
		var fracJourney = distCovered / journeyLength;

		//print("cam pos: " + cam.transform.position + "\n" + "room pos: " + (transform.position + offsetZ) + "\n fracJourney: " + fracJourney);
		//Set our position as a fraction of the distance between the markers.
		cam.transform.position = Vector3.Lerp(cam.transform.position, transform.position + offsetZ, fracJourney);
		}
	if(fracJourney == 1){
			selectedRoom = false;
		}
	}
function OnTriggerEnter2D(other: Collider2D){
	//print("Enter room");
	selectedRoom = true;
	startTime = Time.time;
	journeyLength = Vector3.Distance(cam.transform.position, transform.position + offsetZ);
	//print("Start Time = " + startTime + ", journeyLength = " + journeyLength);
	//cam.transform.position = Vector3.Lerp(cam.transform.position,transform.position + offsetZ,fracJourney);
}

function OnTriggerExit2D(other: Collider2D){
	selectedRoom = false;
}
