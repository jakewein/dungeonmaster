﻿#pragma strict

var position: Vector2;
var colliding = false;

function Start () {
	
}

//function Update () {
//	if( colliding == false) {
//		position = transform.position;
//	}

//}

//function OnCollisionEnter2D(coll: Collision2D ) {
//	colliding = true;
//	transform.position = position;
	//print("Two");
//	colliding = false;
//}
