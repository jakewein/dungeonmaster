﻿#pragma strict

function Start () {

}
function OnTriggerEnter2D( other: Collider2D){
	if(other.gameObject.tag == "hero"){
		Destroy(gameObject);
	}
	}
function Update () {
	
}
